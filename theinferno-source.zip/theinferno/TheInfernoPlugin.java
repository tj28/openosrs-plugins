package net.runelite.client.plugins.theinferno;

import javax.inject.Inject;
import net.runelite.client.plugins.Plugin;
import net.runelite.client.plugins.PluginDescriptor;
import net.runelite.client.ui.overlay.OverlayManager;

@PluginDescriptor(
        name = "The Inferno",
        description = "Highlights NPC actions in The Inferno. Also cows",
        tags = {"pve"},
        enabledByDefault = true
)
public class TheInfernoPlugin extends Plugin
{
    @Inject
    private TheInfernoOverlay overlay;

    @Inject
    private OverlayManager overlayManager;

    @Override
    public void startUp()
    {
        overlayManager.add(overlay);
    }

    @Override
    public void shutDown()
    {
        overlayManager.remove(overlay);
    }
}