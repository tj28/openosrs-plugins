package net.runelite.client.plugins.theinferno;

import java.awt.*;
import java.util.List;
import javax.inject.Inject;

import net.runelite.api.*;
import net.runelite.api.coords.LocalPoint;
import net.runelite.client.ui.FontManager;
import net.runelite.client.ui.overlay.Overlay;
import net.runelite.client.ui.overlay.OverlayLayer;
import net.runelite.client.ui.overlay.OverlayPosition;
import net.runelite.client.ui.overlay.OverlayUtil;
import net.runelite.client.ui.overlay.components.PanelComponent;

class TheInfernoOverlay extends Overlay
{
    private static final Font FONT = FontManager.getRunescapeFont().deriveFont(Font.BOLD, 16);
    private static final Color RED = new Color(221, 44, 0);
    private static final Color GREEN = new Color(0, 200, 83);
    private static final Color ORANGE = new Color(255, 109, 0);
    private static final Color YELLOW = new Color(255, 214, 0);
    private static final Color CYAN = new Color(0, 184, 212);
    private static final Color BLUE = new Color(41, 98, 255);
    private static final Color DEEP_PURPLE = new Color(98, 0, 234);
    private static final Color PURPLE = new Color(170, 0, 255);
    private static final Color GRAY = new Color(158, 158, 158);

    private final Client client;
    private final TheInfernoPlugin plugin;
    private final PanelComponent panelComponent = new PanelComponent();

    @Inject
    private TheInfernoOverlay(Client client, TheInfernoPlugin plugin)
    {
        setPosition(OverlayPosition.DYNAMIC);
        setLayer(OverlayLayer.ABOVE_SCENE);
        this.client = client;
        this.plugin = plugin;
    }

    @Override
    public Dimension render(Graphics2D graphics)
    {
        List<NPC> npcs = client.getNpcs();
        for (NPC npc : npcs)
        {
            NPCDefinition composition = npc.getDefinition();
            Color color = null;
            Polygon canvasTilePoly = null;
            if(npc.getId() == 26167 || npc.getId() == 2805 || npc.getId() == 7691 || npc.getAnimation() == 7574) {
                if(!npc.isDead()) {
                    //canvasTilePoly = npc.getCanvasTilePoly();
                    //OverlayUtil.renderPolygon(graphics, canvasTilePoly, color);
                    color = DEEP_PURPLE;
                    graphics.setColor(color);
                    graphics.fillRect(400, 100, 85, 22);
                    color = YELLOW;
                    graphics.setColor(color);
                    graphics.setFont(new Font("default", Font.BOLD, 16));
                    graphics.drawString("Nibblers", 406, 118);
                    color = null;
                }
            }


            if(npc.getAnimation() == 7597 || npc.getAnimation() == 7582 || npc.getAnimation() == 5849) {
                color = RED;
                graphics.setColor(color);
                graphics.fillRect(430,15,75,75);
                //canvasTilePoly = npc.getCanvasTilePoly();
                //OverlayUtil.renderPolygon(graphics, canvasTilePoly, color);
            } else if(npc.getAnimation() == 7592 || npc.getAnimation() == 7581 || npc.getAnimation() == 7610) {
                color = BLUE;
                graphics.setColor(color);
                graphics.fillRect(276,15,75,75);
                //canvasTilePoly = npc.getCanvasTilePoly();
                //OverlayUtil.renderPolygon(graphics, canvasTilePoly, color);
            } else if(npc.getAnimation() == 7593 || npc.getAnimation() == 7605 || npc.getAnimation() == 7583 || npc.getAnimation() == 7578) {
                color = GREEN;
                graphics.setColor(color);
                graphics.fillRect(353,15,75,75);
                //canvasTilePoly = npc.getCanvasTilePoly();
                //OverlayUtil.renderPolygon(graphics, canvasTilePoly, color);
            } /* else if(npc.getAnimation() == 2639 || npc.getAnimation() == 7601 || npc.getAnimation() == 7585 || npc.getAnimation() == 7611) {
				color = PURPLE;
				graphics.setColor(color);
				graphics.fillRect(440,5,75,75);
				canvasTilePoly = npc.getCanvasTilePoly();
                OverlayUtil.renderPolygon(graphics, canvasTilePoly, color);
			} */


            /*
            if (composition.getConfigs() != null)
            {
                NPCComposition transformedComposition = composition.transform();
                if (transformedComposition == null)
                {
                    color = GRAY;
                }
                else
                {
                    composition = transformedComposition;
                }
            }
             */


			/*
			String text = String.format("%s (ID: %d) (A: %d) (G: %d)",
				composition.getName(),
				composition.getId(),
				npc.getAnimation(),
				npc.getGraphic());
				*/

            //String text = String.format("%d %d", npc.getAnimation(), npc.getGraphic());
            //String text = "";


            if (color != null) {
                if(npc.getAnimation() != -1 || npc.getSpotAnimation() != -1) {
                    //OverlayUtil.renderActorOverlay(graphics, npc, text, color);
                    int size = 1;
                    composition = npc.getTransformedDefinition();
                    if (composition != null)
                    {
                        size = composition.getSize();
                    }
                    LocalPoint lp = npc.getLocalLocation();
                    Polygon tilePoly = Perspective.getCanvasTileAreaPoly(client, lp, size);
                    renderPoly(graphics, color, tilePoly);
                }
            }

        }
        panelComponent.render(graphics);
        return null;
    }

    private void renderPoly(Graphics2D graphics, Color color, Polygon polygon)
    {
        if (polygon != null)
        {
            graphics.setColor(color);
            graphics.setStroke(new BasicStroke(4));
            graphics.draw(polygon);
            graphics.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), 40));
            graphics.fill(polygon);
        }
    }

}
