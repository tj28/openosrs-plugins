package net.runelite.client.plugins.deadman;


import net.runelite.client.config.Config;
import net.runelite.client.config.ConfigGroup;
import net.runelite.client.config.ConfigItem;


@ConfigGroup("deadman")
public interface deadmanConfig extends Config {
    @ConfigItem(
            keyName = "whitelistedPlayers",
            name = "Whitelisted Players",
            description = "Add comma-separated players to whitelist",
            position = 0,
            titleSection = "whitelistedPlayers"
    )
    default String getWhitelistedPlayers()
    {
        return "";
    }

    @ConfigItem(
            keyName = "whitelistedPlayers",
            name = "",
            description = ""
    )
    void setWhitelistedPlayers(String key);


    @ConfigItem(
            keyName = "lowCombatThreshold",
            name = "Alert above CB LV",
            description = "Alert for players above the combat level of",
            position = 1,
            titleSection = "lowCombatThreshold"
    )
    default int getLowCombatThreshold()
    {
        return 1;
    }

    @ConfigItem(
            keyName = "alertInSafezonesEnabled",
            name = "Alert in towns",
            description = "Send alerts even if in town (good for Relleka fishing, yaks etc)",
            position = 2,
            titleSection = "alertInSafezonesEnabled"
    )
    default boolean alertInSafezonesEnabled()
    {
        return false;
    }
}