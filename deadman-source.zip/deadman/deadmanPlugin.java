package net.runelite.client.plugins.deadman;

import javax.inject.Inject;

import com.google.inject.Provides;
import net.runelite.api.SoundEffectID;
import net.runelite.api.coords.WorldPoint;
import net.runelite.client.Notifier;
import net.runelite.api.Client;
import net.runelite.api.Player;
import net.runelite.api.events.GameTick;
import net.runelite.client.config.ConfigManager;
import net.runelite.client.eventbus.Subscribe;
import net.runelite.client.plugins.Plugin;
import net.runelite.client.plugins.PluginDescriptor;
import net.runelite.client.plugins.PluginType;
import org.pf4j.Extension;

import java.awt.TrayIcon;
import java.util.Arrays;

@Extension
@PluginDescriptor(
	name = "Deadman",
	enabledByDefault = false,
	hidden = false,
	description = "Alerts when players are detected. Warning safezone mapping not exact",
	tags = {"dmm", "deadman", "sdmm"},
	type = PluginType.PVP
)
public class deadmanPlugin extends Plugin
{
	@Inject
	private Client client;

	@Inject
	private Notifier notifier;

	@Inject
	private deadmanConfig config;

	@Provides
	deadmanConfig provideConfig(ConfigManager configManager)
	{
		return configManager.getConfig(deadmanConfig.class);
	}

	@Subscribe
	private void onGametick(GameTick gameTick)
	{
		Player local = client.getLocalPlayer();
		WorldPoint localWorld = local.getWorldLocation();
		//LocalPoint localPoint = client.getLocalPlayer().getLocalLocation();
		int currRegionID = localWorld.getRegionID();
		int currFloor = localWorld.getPlane();
		boolean areWeInTown = Arrays.asList(12850, 12853, 12597, 12598, 12854, 11828, 12084, 14646, 10288, 10547, 10291, 9782, 9781, 9525, 9526, 10553, 10297, 13099, 9275, 9351).contains(currRegionID);
		boolean areWeOnPlaneThree = false; //dirty fix for rooftop agility
		if(localWorld.getPlane() == 3)
			areWeOnPlaneThree = true;

		for (Player p : client.getPlayers())
		{
			if(p != local)
			{
				//area test
				if(areWeOnPlaneThree == true || config.alertInSafezonesEnabled() == true || Arrays.asList(12850, 12853, 12597, 12598, 12854, 11828, 12084, 14646, 10288, 10547, 10291, 9782, 9781, 9525, 9526, 10553, 10297, 13099).contains(currRegionID) == false)
				{
					//make sure the cb level is high enough and player isn't whitelisted
					if(p.getCombatLevel() > config.getLowCombatThreshold() && config.getWhitelistedPlayers().contains(p.getName()) == false)
					{
						callAlertMsg(p);
					}
				}
			}
		}
	}

	private void callAlertMsg(Player p)
	{
		String alertmsg = "**PLAYER DETECTED** " + p.getName() + " COMBAT LV " + Integer.toString(p.getCombatLevel());
		notifier.notify(alertmsg, TrayIcon.MessageType.WARNING);
		client.playSoundEffect(SoundEffectID.UI_BOOP);
	}
}